package com.tup.commons.base;

public class UpdOrders {
	private String syvr01;

	public String getSyvr01() {
		return syvr01;
	}

	public void setSyvr01(String syvr01) {
		this.syvr01 = syvr01;
	}
	

}
