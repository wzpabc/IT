package com.tup.commons.interceptor;

public class Interceptor {

}
