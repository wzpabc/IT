package com.tup.mssql.model;

import java.math.BigDecimal;
import java.util.Date;

public class OrderDetail extends OrderDetailKey {
    private String sdco;

    private Integer sdan8;

    private Integer sdshan;

    private Integer sdpa8;

    private String sdlnty;

    private Date sddrqj;

    private Date sdtrdj;

    private Date sdpddj;

    private Date sdopdj;

    private Date sdaddj;

    private Date sdcndj;

    private Date sddgl;

    private Date sdrsdj;

    private String sdvr02;

    private String sdlitm;

    private String sdlocn;

    private String sdlotn;

    private String sddsc1;

    private String sddsc2;

    private Integer sdnxtr;

    private Integer sdlttr;

    private String sdemcu;

    private String sdrlit;

    private String sdktln;

    private String sdcpnt;

    private String sdrkit;

    private String sdktp;

    private String sdsrp1;

    private String sdsrp2;

    private String sdsrp3;

    private String sdsrp4;

    private String sdsrp5;

    private String sdprp1;

    private String sdprp2;

    private String sdprp3;

    private String sdprp4;

    private String sdprp5;

    private String sduom;

    private Long sduorg;

    private Long sdsoqs;

    private Long sdsobk;

    private Long sdsocn;

    private String sdcomm;

    private BigDecimal sduprc;

    private BigDecimal sdaexp;

    private Integer sdpsn;

    private String sdback;

    private String sdsbal;

    private String sdapts;

    private String sduom1;

    private Long sdpqor;

    private String sduom2;

    private Long sdsqor;

    private Integer sdcars;

    private String sdcnid;

    private Integer sddeln;

    private String sdrcd;

    private Long sdgrwt;

    private String sdglc;

    private String sdvr01;

    private String sduser;

    private Date sdupmj;

    private Date jdeUpdatedate;

    private Date ktProcessdate;

    private Date ktFaildate;

    private Integer ktRetrytimes;

    private String ktErrorlog;

    private String isCheck;

    private Date fmsProcessDate;

    public String getSdco() {
        return sdco;
    }

    public void setSdco(String sdco) {
        this.sdco = sdco == null ? null : sdco.trim();
    }

    public Integer getSdan8() {
        return sdan8;
    }

    public void setSdan8(Integer sdan8) {
        this.sdan8 = sdan8;
    }

    public Integer getSdshan() {
        return sdshan;
    }

    public void setSdshan(Integer sdshan) {
        this.sdshan = sdshan;
    }

    public Integer getSdpa8() {
        return sdpa8;
    }

    public void setSdpa8(Integer sdpa8) {
        this.sdpa8 = sdpa8;
    }

    public String getSdlnty() {
        return sdlnty;
    }

    public void setSdlnty(String sdlnty) {
        this.sdlnty = sdlnty == null ? null : sdlnty.trim();
    }

    public Date getSddrqj() {
        return sddrqj;
    }

    public void setSddrqj(Date sddrqj) {
        this.sddrqj = sddrqj;
    }

    public Date getSdtrdj() {
        return sdtrdj;
    }

    public void setSdtrdj(Date sdtrdj) {
        this.sdtrdj = sdtrdj;
    }

    public Date getSdpddj() {
        return sdpddj;
    }

    public void setSdpddj(Date sdpddj) {
        this.sdpddj = sdpddj;
    }

    public Date getSdopdj() {
        return sdopdj;
    }

    public void setSdopdj(Date sdopdj) {
        this.sdopdj = sdopdj;
    }

    public Date getSdaddj() {
        return sdaddj;
    }

    public void setSdaddj(Date sdaddj) {
        this.sdaddj = sdaddj;
    }

    public Date getSdcndj() {
        return sdcndj;
    }

    public void setSdcndj(Date sdcndj) {
        this.sdcndj = sdcndj;
    }

    public Date getSddgl() {
        return sddgl;
    }

    public void setSddgl(Date sddgl) {
        this.sddgl = sddgl;
    }

    public Date getSdrsdj() {
        return sdrsdj;
    }

    public void setSdrsdj(Date sdrsdj) {
        this.sdrsdj = sdrsdj;
    }

    public String getSdvr02() {
        return sdvr02;
    }

    public void setSdvr02(String sdvr02) {
        this.sdvr02 = sdvr02 == null ? null : sdvr02.trim();
    }

    public String getSdlitm() {
        return sdlitm;
    }

    public void setSdlitm(String sdlitm) {
        this.sdlitm = sdlitm == null ? null : sdlitm.trim();
    }

    public String getSdlocn() {
        return sdlocn;
    }

    public void setSdlocn(String sdlocn) {
        this.sdlocn = sdlocn == null ? null : sdlocn.trim();
    }

    public String getSdlotn() {
        return sdlotn;
    }

    public void setSdlotn(String sdlotn) {
        this.sdlotn = sdlotn == null ? null : sdlotn.trim();
    }

    public String getSddsc1() {
        return sddsc1;
    }

    public void setSddsc1(String sddsc1) {
        this.sddsc1 = sddsc1 == null ? null : sddsc1.trim();
    }

    public String getSddsc2() {
        return sddsc2;
    }

    public void setSddsc2(String sddsc2) {
        this.sddsc2 = sddsc2 == null ? null : sddsc2.trim();
    }

    public Integer getSdnxtr() {
        return sdnxtr;
    }

    public void setSdnxtr(Integer sdnxtr) {
        this.sdnxtr = sdnxtr;
    }

    public Integer getSdlttr() {
        return sdlttr;
    }

    public void setSdlttr(Integer sdlttr) {
        this.sdlttr = sdlttr;
    }

    public String getSdemcu() {
        return sdemcu;
    }

    public void setSdemcu(String sdemcu) {
        this.sdemcu = sdemcu == null ? null : sdemcu.trim();
    }

    public String getSdrlit() {
        return sdrlit;
    }

    public void setSdrlit(String sdrlit) {
        this.sdrlit = sdrlit == null ? null : sdrlit.trim();
    }

    public String getSdktln() {
        return sdktln;
    }

    public void setSdktln(String sdktln) {
        this.sdktln = sdktln == null ? null : sdktln.trim();
    }

    public String getSdcpnt() {
        return sdcpnt;
    }

    public void setSdcpnt(String sdcpnt) {
        this.sdcpnt = sdcpnt == null ? null : sdcpnt.trim();
    }

    public String getSdrkit() {
        return sdrkit;
    }

    public void setSdrkit(String sdrkit) {
        this.sdrkit = sdrkit == null ? null : sdrkit.trim();
    }

    public String getSdktp() {
        return sdktp;
    }

    public void setSdktp(String sdktp) {
        this.sdktp = sdktp == null ? null : sdktp.trim();
    }

    public String getSdsrp1() {
        return sdsrp1;
    }

    public void setSdsrp1(String sdsrp1) {
        this.sdsrp1 = sdsrp1 == null ? null : sdsrp1.trim();
    }

    public String getSdsrp2() {
        return sdsrp2;
    }

    public void setSdsrp2(String sdsrp2) {
        this.sdsrp2 = sdsrp2 == null ? null : sdsrp2.trim();
    }

    public String getSdsrp3() {
        return sdsrp3;
    }

    public void setSdsrp3(String sdsrp3) {
        this.sdsrp3 = sdsrp3 == null ? null : sdsrp3.trim();
    }

    public String getSdsrp4() {
        return sdsrp4;
    }

    public void setSdsrp4(String sdsrp4) {
        this.sdsrp4 = sdsrp4 == null ? null : sdsrp4.trim();
    }

    public String getSdsrp5() {
        return sdsrp5;
    }

    public void setSdsrp5(String sdsrp5) {
        this.sdsrp5 = sdsrp5 == null ? null : sdsrp5.trim();
    }

    public String getSdprp1() {
        return sdprp1;
    }

    public void setSdprp1(String sdprp1) {
        this.sdprp1 = sdprp1 == null ? null : sdprp1.trim();
    }

    public String getSdprp2() {
        return sdprp2;
    }

    public void setSdprp2(String sdprp2) {
        this.sdprp2 = sdprp2 == null ? null : sdprp2.trim();
    }

    public String getSdprp3() {
        return sdprp3;
    }

    public void setSdprp3(String sdprp3) {
        this.sdprp3 = sdprp3 == null ? null : sdprp3.trim();
    }

    public String getSdprp4() {
        return sdprp4;
    }

    public void setSdprp4(String sdprp4) {
        this.sdprp4 = sdprp4 == null ? null : sdprp4.trim();
    }

    public String getSdprp5() {
        return sdprp5;
    }

    public void setSdprp5(String sdprp5) {
        this.sdprp5 = sdprp5 == null ? null : sdprp5.trim();
    }

    public String getSduom() {
        return sduom;
    }

    public void setSduom(String sduom) {
        this.sduom = sduom == null ? null : sduom.trim();
    }

    public Long getSduorg() {
        return sduorg;
    }

    public void setSduorg(Long sduorg) {
        this.sduorg = sduorg;
    }

    public Long getSdsoqs() {
        return sdsoqs;
    }

    public void setSdsoqs(Long sdsoqs) {
        this.sdsoqs = sdsoqs;
    }

    public Long getSdsobk() {
        return sdsobk;
    }

    public void setSdsobk(Long sdsobk) {
        this.sdsobk = sdsobk;
    }

    public Long getSdsocn() {
        return sdsocn;
    }

    public void setSdsocn(Long sdsocn) {
        this.sdsocn = sdsocn;
    }

    public String getSdcomm() {
        return sdcomm;
    }

    public void setSdcomm(String sdcomm) {
        this.sdcomm = sdcomm == null ? null : sdcomm.trim();
    }

    public BigDecimal getSduprc() {
        return sduprc;
    }

    public void setSduprc(BigDecimal sduprc) {
        this.sduprc = sduprc;
    }

    public BigDecimal getSdaexp() {
        return sdaexp;
    }

    public void setSdaexp(BigDecimal sdaexp) {
        this.sdaexp = sdaexp;
    }

    public Integer getSdpsn() {
        return sdpsn;
    }

    public void setSdpsn(Integer sdpsn) {
        this.sdpsn = sdpsn;
    }

    public String getSdback() {
        return sdback;
    }

    public void setSdback(String sdback) {
        this.sdback = sdback == null ? null : sdback.trim();
    }

    public String getSdsbal() {
        return sdsbal;
    }

    public void setSdsbal(String sdsbal) {
        this.sdsbal = sdsbal == null ? null : sdsbal.trim();
    }

    public String getSdapts() {
        return sdapts;
    }

    public void setSdapts(String sdapts) {
        this.sdapts = sdapts == null ? null : sdapts.trim();
    }

    public String getSduom1() {
        return sduom1;
    }

    public void setSduom1(String sduom1) {
        this.sduom1 = sduom1 == null ? null : sduom1.trim();
    }

    public Long getSdpqor() {
        return sdpqor;
    }

    public void setSdpqor(Long sdpqor) {
        this.sdpqor = sdpqor;
    }

    public String getSduom2() {
        return sduom2;
    }

    public void setSduom2(String sduom2) {
        this.sduom2 = sduom2 == null ? null : sduom2.trim();
    }

    public Long getSdsqor() {
        return sdsqor;
    }

    public void setSdsqor(Long sdsqor) {
        this.sdsqor = sdsqor;
    }

    public Integer getSdcars() {
        return sdcars;
    }

    public void setSdcars(Integer sdcars) {
        this.sdcars = sdcars;
    }

    public String getSdcnid() {
        return sdcnid;
    }

    public void setSdcnid(String sdcnid) {
        this.sdcnid = sdcnid == null ? null : sdcnid.trim();
    }

    public Integer getSddeln() {
        return sddeln;
    }

    public void setSddeln(Integer sddeln) {
        this.sddeln = sddeln;
    }

    public String getSdrcd() {
        return sdrcd;
    }

    public void setSdrcd(String sdrcd) {
        this.sdrcd = sdrcd == null ? null : sdrcd.trim();
    }

    public Long getSdgrwt() {
        return sdgrwt;
    }

    public void setSdgrwt(Long sdgrwt) {
        this.sdgrwt = sdgrwt;
    }

    public String getSdglc() {
        return sdglc;
    }

    public void setSdglc(String sdglc) {
        this.sdglc = sdglc == null ? null : sdglc.trim();
    }

    public String getSdvr01() {
        return sdvr01;
    }

    public void setSdvr01(String sdvr01) {
        this.sdvr01 = sdvr01 == null ? null : sdvr01.trim();
    }

    public String getSduser() {
        return sduser;
    }

    public void setSduser(String sduser) {
        this.sduser = sduser == null ? null : sduser.trim();
    }

    public Date getSdupmj() {
        return sdupmj;
    }

    public void setSdupmj(Date sdupmj) {
        this.sdupmj = sdupmj;
    }

    public Date getJdeUpdatedate() {
        return jdeUpdatedate;
    }

    public void setJdeUpdatedate(Date jdeUpdatedate) {
        this.jdeUpdatedate = jdeUpdatedate;
    }

    public Date getKtProcessdate() {
        return ktProcessdate;
    }

    public void setKtProcessdate(Date ktProcessdate) {
        this.ktProcessdate = ktProcessdate;
    }

    public Date getKtFaildate() {
        return ktFaildate;
    }

    public void setKtFaildate(Date ktFaildate) {
        this.ktFaildate = ktFaildate;
    }

    public Integer getKtRetrytimes() {
        return ktRetrytimes;
    }

    public void setKtRetrytimes(Integer ktRetrytimes) {
        this.ktRetrytimes = ktRetrytimes;
    }

    public String getKtErrorlog() {
        return ktErrorlog;
    }

    public void setKtErrorlog(String ktErrorlog) {
        this.ktErrorlog = ktErrorlog == null ? null : ktErrorlog.trim();
    }

    public String getIsCheck() {
        return isCheck;
    }

    public void setIsCheck(String isCheck) {
        this.isCheck = isCheck == null ? null : isCheck.trim();
    }

    public Date getFmsProcessDate() {
        return fmsProcessDate;
    }

    public void setFmsProcessDate(Date fmsProcessDate) {
        this.fmsProcessDate = fmsProcessDate;
    }
}